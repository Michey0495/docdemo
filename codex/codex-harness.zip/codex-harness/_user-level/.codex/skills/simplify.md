---
description: 変更コードを再利用性・命名・効率の観点でレビューし、必要なら修正する
argument-hint: [--review-only]
---
# simplify

## 観点
1. 既存ユーティリティで置き換えできないか
2. 命名は verb-noun / isXxx / hasXxx になっているか
3. 早すぎる抽象化(YAGNI違反)になっていないか
4. 重複コード(DRY違反)がないか
5. mutateしている箇所(immutable違反)がないか

## 動作
- /simplify を投下するとレビュー → 修正提案 → 同意ある場合のみ反映
- レビューだけ欲しい場合は /simplify --review-only

引数: $ARGUMENTS (--review-only でレビューのみ)
