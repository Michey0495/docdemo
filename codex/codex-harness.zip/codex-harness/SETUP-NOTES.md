# ファイルではなく設定画面・外部サービス側で行う項目

## 工程10 保守運用 — launchd / cron（外部スケジューラから codex exec 起動）

# crontab -e
# 毎朝9時 JST に Codex CLI を非対話モードで起動
TZ=Asia/Tokyo
0 9 * * * /usr/local/bin/codex exec \
  --profile prod-readonly \
  --skip-git-repo-check \
  "/health-check 24h を実行し、エラー率/レスポンス分布/CSV連携成否を Datadog MCP 経由で取得し reports/daily/$(date +\%Y-\%m-\%d).md にまとめる。閾値超えがあれば Slack に通知。" \
  >> /var/log/codex/daily-health.log 2>&1

# Codex CLI 単体には cron 機能が無いため、launchd / cron / systemd timer / GitHub Actions 等の
# 外部スケジューラから codex exec を呼び出す運用が公式推奨パターン
