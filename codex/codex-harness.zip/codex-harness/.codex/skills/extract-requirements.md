---
description: 文字起こしtxtを req_extractor に渡し、req_reviewer で自動レビューまで完走
argument-hint: <transcript-path>
---
# 要求抽出パイプライン
1. `req_extractor` サブエージェントを spawn して $ARGUMENTS を解析
2. 完了したら `req_reviewer` サブエージェントを spawn して docs/01-requirements-raw.md を点検
3. WARN/ERROR があれば次工程に進まず、人間に提示して確認

引数: $1 = transcript path
全引数: $ARGUMENTS
