---
description: ユーザーストーリーIDを引数に、ブランチ作成→実装→テスト→PR作成まで一気通貫
argument-hint: <US-XXX>
---
# 実装パイプライン

$1 のストーリーを実装します。

## 手順
1. specification/stories/$1.md と design/detail/sequence/$1-*.md を読込
2. `git checkout -b feat/$1-...`
3. 詳細設計に従い実装
   - PostToolUse: typecheck/lint:fix が自動で走る
   - Stop: 全テスト実行
4. `/simplify --review-only` を実行し、対応必要なら修正
5. `gh pr create` でPR作成

## 守るべきこと
- src/ 以外には書かない（sandbox_workspace_write.writable_roots で制限）
- mutateしない（AGENTS.md 規約）

引数: $1 = US-ID
全引数: $ARGUMENTS
