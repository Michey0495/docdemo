---
description: 要件定義書(RDD)の標準テンプレートを適用。ISO/IEC/IEEE 29148準拠の章構成を強制し、関連要求IDのトレーサを自動付与する
argument-hint: <requirements-final-path>
---
# RDD章構成

1. はじめに（背景・目的・対象範囲）
2. 用語の定義
3. 業務概要
4. 業務フロー（As-Is / To-Be 各Mermaid）
5. システム化の範囲
6. 機能要件
7. 非機能要件
8. 外部システム連携
9. データ要件
10. セキュリティ要件
11. 運用要件
12. 制約条件
13. 移行要件
14. 教育・サポート
15. 受入基準
16. 用語集
（※ 第17-20章はプロジェクト個別追記）

## 関連リソース
- ./templates/rdd-skeleton.md
- ./templates/glossary.md

引数: $1 = requirements final path
全引数: $ARGUMENTS
