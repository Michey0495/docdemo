---
description: security_review / code_reviewer / qa_engineer を並列起動して総括レポートを作成
argument-hint: <PR_NUMBER>
---
# 並列レビュー

[agents] max_threads=6 設定下で3つのサブエージェントを並行 spawn:

```
security_review     "PR #$1 の差分をOWASP Top10観点でレビュー"
code_reviewer       "PR #$1 の差分を AGENTS.md 規約観点でレビュー"
qa_engineer         "PR #$1 のストーリーから単体・E2Eテストを生成・実行"
```

3者の出力を docs/08-review-report.md に統合し、自動修正可能な指摘は適用、人判断が必要なものは残置。

引数: $1 = PR番号
