---
description: 障害IDを引数に incident_responder を起動、PostMortemドラフトまで作成
argument-hint: <INC-YYYY-MM-DD>
---
# 障害対応パイプライン
incident_responder サブエージェントを spawn し、$1 の関連ログを集約。
postmortem skill を適用し、ドラフトを incidents/$1/postmortem.md に書き出す。

引数: $1 = INC-YYYY-MM-DD
全引数: $ARGUMENTS
