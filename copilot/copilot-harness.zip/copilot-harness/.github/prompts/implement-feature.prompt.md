---
mode: agent
description: ユーザーストーリーIDを入力に、ブランチ作成→実装→テスト→PR作成まで一気通貫
tools: ['codebase', 'editFiles', 'runInTerminal', 'runTests']
---
# 実装パイプライン

${input:storyId} のストーリーを実装します。

## 手順
1. specification/stories/${input:storyId}.md と design/detail/sequence/ を読込
2. `git checkout -b feat/${input:storyId}-...`
3. 詳細設計に従い実装（typecheck/lint を都度実行して確認）
4. runTests で全テスト実行、落ちたら修正
5. `gh pr create` でPR作成（Copilot Code Review が自動で走る）

## 守るべきこと
- src/ 以外には書かない
- mutateしない（.github/copilot-instructions.md 規約）

呼び出し: チャットで /implement-feature と入力
