---
mode: agent
description: 文字起こしtxtを解析し、要求抽出からセルフレビューまで完走
tools: ['codebase', 'search', 'editFiles']
---
# 要求抽出パイプライン
1. ${input:transcriptPath} を req-extractor モードの規約で解析
2. 抽出結果を docs/01-requirements-raw.md に書き出す
3. req-reviewer の観点でセルフレビューし、WARN/ERROR があれば
   次工程に進まず、人間に提示して確認

呼び出し: チャットで /extract-requirements と入力
