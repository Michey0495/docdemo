---
mode: agent
description: security-review / code-reviewer / qa-engineer の3観点レビューを実行して総括レポートを作成
tools: ['codebase', 'search', 'runInTerminal', 'runTests', 'github']
---
# 3観点レビュー

PR #${input:prNumber} を3つの観点で順にレビュー:

1. security-review instructions の観点で差分を精査
2. code-reviewer モードの観点で規約・不変性・性能を精査
3. qa-engineer モードの観点で受入基準をテスト化し実行

3者の出力を docs/08-review-report.md に統合し、
自動修正可能な指摘は適用、人判断が必要なものは残置。

呼び出し: チャットで /full-review と入力
