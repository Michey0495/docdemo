---
mode: agent
description: 障害IDを入力に、ログ集約からPostMortemドラフトまで作成
tools: ['codebase', 'editFiles', 'datadog', 'slack']
---
# 障害対応パイプライン
incident-responder モードの手順で ${input:incidentId} の関連ログを集約。
postmortem instructions を適用し、ドラフトを
incidents/${input:incidentId}/postmortem.md に書き出す。

呼び出し: チャットで /incident-respond と入力
