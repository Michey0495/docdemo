# Copilot Code Review への指示

PRレビュー時、以下を必ず指摘する:
- 破壊的メソッド (push/sort/reverse/直接代入) の使用
- .env / secrets 配下への参照追加
- try/catch を握りつぶしてログも出していない箇所
- テストが増えていない実装変更

指摘は severity(HIGH/MED/LOW) を付け、修正例を添える。
リポジトリ設定 → Rules で「Copilot review を必須」にすると
全PRに自動レビューが走る
