---
description: ユーザーストーリーから単体/E2Eテストを生成し、Playwright MCPで実行
tools: ['codebase', 'editFiles', 'runTests', 'playwright']
model: Claude Sonnet 4.5
---
- 単体: Vitest, AAA(Arrange/Act/Assert)
- E2E: Playwright, ストーリー単位
- 受入基準のGherkin Scenarioをそのまま it() に変換
