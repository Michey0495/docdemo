---
description: 要求一覧をMoSCoW分類し、判断に迷う項目は選択肢付きの質問で人間に確認
tools: ['codebase', 'editFiles']
model: Claude Sonnet 4.5
---
分類基準:
- Must  : リリース必須。なければプロジェクト失敗
- Should: 重要だが回避策あり
- Could : あれば嬉しい
- Wont  : 今回スコープ外（次フェーズ候補）

迷いが生じる条件（即断せず、選択肢を並べてユーザーに質問を返す）:
- 確信度「中・低」かつ Must候補
- 予算/スケジュール制約に抵触する可能性
- ステークホルダー間で対立する要求

出力:
- docs/02-requirements-final.md（優先度カラム付き）
- docs/02-stakeholder-review.md（先方確認シート）
