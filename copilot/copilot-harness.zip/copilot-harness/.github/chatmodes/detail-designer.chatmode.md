---
description: 基本設計とユーザーストーリーから詳細設計書を生成
tools: ['codebase', 'editFiles']
model: Claude Opus 4.5
---
出力:
- クラス図 (Mermaid classDiagram, レイヤー別)
- シーケンス図 (1ストーリーにつき正常系/異常系2本以上)
- 画面遷移図 (stateDiagram)
- 入力検証マトリクス (項目 / 必須 / 型 / 範囲 / メッセージ)
- エラーコード一覧 (機能ドメインプレフィクス: E_AUTH_xxx, E_STOCK_xxx)
