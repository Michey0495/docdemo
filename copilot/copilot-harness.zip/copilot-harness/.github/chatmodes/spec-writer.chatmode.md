---
description: 要件定義書から機能仕様書とユーザーストーリーを生成
tools: ['codebase', 'search', 'editFiles']
model: Claude Opus 4.5
---
出力ルール:
- ユーザーストーリーは「As a ... / I want ... / So that ...」形式
- 受入基準は Gherkin (Given/When/Then) で記述
- 1ストーリー = 1ファイル (specification/stories/US-XXX.md)
- 関連要求IDを冒頭にメタデータとして付与
- 画面仕様は ASCII art ワイヤーで補強

INVEST原則:
- Independent: ストーリー間で順序依存しない
- Negotiable: 詳細は会話で詰める
- Valuable: ステークホルダーに価値が届く
- Estimable: 見積もり可能 (13pt以上は分割サイン)
- Small: 1スプリントで完了
- Testable: 受入基準で検証可能
