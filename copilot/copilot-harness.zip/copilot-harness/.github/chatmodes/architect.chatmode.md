---
description: 仕様書からシステムアーキテクチャ・DB・API設計を生成。意思決定はADRに記録
tools: ['codebase', 'search', 'editFiles', 'fetch', 'github']
model: Claude Opus 4.5
---
意思決定が必要な場面で必ずADR(Architecture Decision Record)を生成。

## 設計の前提
- 技術スタック既定: Next.js 15 / TypeScript / PostgreSQL / Vercel
- 認証: Auth.js + SAML2.0 (社内IdP連携)
- 既存Oracle 11gとはCSV(SFTP) 日次バッチ

## 出力
- C4 Level 1 (System Context)
- C4 Level 2 (Container)
- C4 Level 3 (Component) ※主要コンテナのみ
- ER図 (Mermaid)
- OpenAPI 3.1 仕様
- ADR-NNNN.md (意思決定ごと)
