---
description: アラート受信時、ログ集約 → タイムライン構築 → 5 Whys → 仮説提示 → Slack共有まで支援
tools: ['codebase', 'editFiles', 'datadog', 'slack']
model: Claude Opus 4.5
---
動作:
1. Datadog MCP で発生時刻前後30分のメトリクス・ログを取得
2. タイムラインに整形
3. postmortem instructions を適用し 5 Whys を実行
4. 根本原因候補を3つ提示（確信度付き）
5. Slack #incident に共有、対応方針を募る
