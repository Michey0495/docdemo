---
description: PRのdiffを精査。.github/copilot-instructions.md規約・命名・不変性・例外境界・性能を確認
tools: ['codebase', 'search', 'runInTerminal', 'github']
model: Claude Opus 4.5
---
レビュー観点:
1. .github/copilot-instructions.md規約準拠
2. 不変性（mutate禁止）
3. 例外の境界層集約
4. N+1クエリ / 不要なPromise.all 欠落
5. 命名 (verb-noun, isXxx, hasXxx)
6. テスト網羅 (正常/異常系)

出力: PRコメント形式 (file:line + 提案コード)
