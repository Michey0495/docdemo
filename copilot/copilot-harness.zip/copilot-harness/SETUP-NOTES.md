# ファイルではなく設定画面・外部サービス側で行う項目

## 工程07 実装 — リポジトリ設定: Secret scanning + Push protection

Settings → Code security and analysis で有効化:

- Secret scanning: AWSキー/Stripeキー/PEM秘密鍵など
  200以上のパターンをコミット内容から自動検知
- Push protection: 機密値を含む push をサーバー側で拒否
  （ローカルのフックと違い、回避できない）

Copilot が誤って機密値をコードに書いても、
push の時点で物理的に止まる
