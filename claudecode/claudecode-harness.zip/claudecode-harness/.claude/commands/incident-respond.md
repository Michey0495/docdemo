---
description: 障害IDを引数にincident-responderを起動、PostMortemドラフトまで作成
argument-hint: <INC-YYYY-MM-DD>
allowed-tools: Task, Read, Write, mcp__datadog__*, mcp__slack__*
---
# 障害対応パイプライン
`@incident-responder` を起動し、$ARGUMENTS の関連ログを集約。
postmortem skill を適用し、ドラフトを incidents/$ARGUMENTS/postmortem.md に書き出す。
