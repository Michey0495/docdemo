---
description: security-review / code-reviewer / qa-engineer を並列起動して総括レポートを作成
allowed-tools: Task, Read, Write, Bash
---
# 並列レビュー

3エージェントを並行起動:

```
@security-review     "PR #$ARGUMENTS の差分をレビュー"
@code-reviewer       "PR #$ARGUMENTS の差分をレビュー"
@qa-engineer         "PR #$ARGUMENTS のストーリーから単体・E2Eテストを生成・実行"
```

3者の出力を docs/08-review-report.md に統合し、自動修正可能な指摘は適用、人判断が必要なものは残置。
