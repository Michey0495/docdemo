---
description: 文字起こしtxtを req-extractor に渡し、req-reviewer で自動レビューまで完走
argument-hint: <transcript-path>
allowed-tools: Read, Write, Task
---
# 要求抽出パイプライン
1. `@req-extractor` を起動して $ARGUMENTS を解析
2. 完了したら `@req-reviewer` を起動して docs/01-requirements-raw.md を点検
3. WARN/ERROR があれば次工程に進まず、人間に提示して確認
