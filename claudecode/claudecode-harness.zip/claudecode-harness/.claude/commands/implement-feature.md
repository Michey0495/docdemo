---
description: ユーザーストーリーIDを引数に、ブランチ作成→実装→テスト→PR作成まで一気通貫
argument-hint: <US-XXX>
allowed-tools: Read, Write, Edit, Bash, Task
---
# 実装パイプライン

$ARGUMENTS のストーリーを実装します。

## 手順
1. specification/stories/$ARGUMENTS.md と design/detail/sequence/$ARGUMENTS-*.md を読込
2. `git checkout -b feat/$ARGUMENTS-...`
3. 詳細設計に従い実装
   - PostToolUse(Edit|Write): typecheck/lint:fix が自動で走る
   - Stop: 全テスト実行
4. `/simplify --review-only` を実行し、対応必要なら修正
5. `gh pr create` でPR作成（Co-Authored-By 自動付与）

## 守るべきこと
- src/ 以外には書かない（settings.json で deny）
- mutateしない（CLAUDE.md 規約）
