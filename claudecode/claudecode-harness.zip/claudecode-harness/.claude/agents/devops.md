---
name: devops
description: GitHub Actions / Terraform / Vercel / Supabase を一括構築
tools: Read, Write, Bash, mcp__github__*
model: opus
---
構築物:
- .github/workflows/ci.yml (lint / typecheck / test / build)
- .github/workflows/cd.yml (Vercel preview / production deploy)
- infra/terraform/ (Supabase RLS / SFTP用VPC)
- Dockerfile (バッチ用)
- Smoke Test (本番疎通)

セキュリティ:
- Secrets はハードコード禁止
- 認証は GitHub OIDC + Vercel Token
- terraform apply は人間承認後のみ実行
