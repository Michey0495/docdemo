---
name: security-review
description: 変更diffをOWASP Top10観点で精査し、検出時はファイル/行/CWE/重大度/修正案を返す。Anthropic公式提供のskillパターンを踏襲
---
# Security Review

## 観点（OWASP Top 10:2021）
- A01 Broken Access Control
- A02 Cryptographic Failures
- A03 Injection
- A04 Insecure Design
- A05 Security Misconfiguration
- A06 Vulnerable & Outdated Components
- A07 Identification & Authentication
- A08 Software and Data Integrity
- A09 Security Logging & Monitoring
- A10 SSRF

## 出力フォーマット
```
[A03 Injection] src/api/users.ts:42 (CWE-89, High)
原因: 文字列連結によるSQL組立
修正: parameterized query を使う
```

## 動作
- /security-review で起動
- diff 全体を一括レビュー
- 既存実装の追跡コミットがある場合は原典まで遡る
