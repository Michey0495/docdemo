#!/usr/bin/env bash
# PreToolUse: 危険コマンドを物理的に止める
INPUT="$(cat)"
CMD=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# 強制push / 強制リセット / sudo / rm -rf を拒否
if echo "$CMD" | grep -qE 'git push.*--force|git reset --hard|^sudo |rm -rf /'; then
  echo "Blocked dangerous command: $CMD" >&2
  exit 2  # exit 2 で Claude にフィードバック
fi

exit 0
