#!/usr/bin/env bash
# PreToolUse(Write|Edit): 機密値の混入を検知
INPUT="$(cat)"
CONTENT=$(echo "$INPUT" | jq -r '.tool_input.content // .tool_input.new_string // empty')

# AWS / Stripe / PEM / API Token 様パターン
if echo "$CONTENT" | grep -qE 'AKIA[0-9A-Z]{16}|sk_live_[0-9a-zA-Z]{24}|-----BEGIN [A-Z ]+PRIVATE KEY-----'; then
  echo "Possible secret detected. 書込を中断します。" >&2
  exit 2
fi

exit 0
