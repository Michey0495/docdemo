---
description: 文字起こしtxtを「要求抽出モード」で解析し、「要求レビューモード」で自動レビューまで完走するワークフロー
---
# 要求抽出パイプライン

Agent Mode で `@extract-requirements <transcript-path>` と打つと、このNotepadが Agent のコンテキストに展開される。

## 手順
1. 「要求抽出モード」(.cursor/modes/req-extractor.json) に切替、指定パスを解析
2. docs/01-requirements-raw.md を出力したら「要求レビューモード」に切替
3. 同ファイルを点検し、WARN/ERROR があれば次工程に進まず人間に提示

## モード切替
- Agent Mode 右上のモード選択メニュー、または Cmd+. で切替
- Custom Mode は .cursor/modes/ 配下を Settings > Modes から有効化
