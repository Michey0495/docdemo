---
description: ユーザーストーリーIDを引数に、ブランチ作成→実装→テスト→PR作成まで一気通貫
---
# 実装パイプライン

Agent Mode で `@implement-feature US-XXX` で起動。

## 手順
1. specification/stories/US-XXX.md と design/detail/sequence/US-XXX-*.md を読込
2. `git checkout -b feat/US-XXX-...`
3. 詳細設計に従い実装
   - lint-staged が typecheck/lint:fix を自動実行
   - pre-push hook で全テスト実行
4. `@simplify --review-only` を実行し、対応必要なら修正
5. `gh pr create` でPR作成

## 守るべきこと
- src/ 以外には書かない（.cursor/settings.json の allowedWritePaths で制限）
- mutateしない（.cursor/rules/coding-standards.mdc）
