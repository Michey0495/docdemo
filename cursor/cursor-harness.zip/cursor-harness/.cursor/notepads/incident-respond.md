---
description: 障害IDを引数に「障害対応モード」を起動、PostMortemドラフトまで作成
---
# 障害対応パイプライン

Agent Mode で `@incident-respond INC-YYYY-MM-DD` で起動。

1. 「障害対応モード」(.cursor/modes/incident-responder.json) に切替
2. Datadog MCP で関連ログを集約
3. @postmortem Notepad を適用
4. ドラフトを incidents/<INC-ID>/postmortem.md に書き出す
