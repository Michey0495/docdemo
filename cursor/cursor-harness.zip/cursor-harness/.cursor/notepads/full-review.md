---
description: security-review / code-reviewer / qa-engineer の3モードを並列実行して総括レポートを作成
---
# 並列レビュー

Agent Mode で `@full-review <PR_NUMBER>` で起動。

Cursor の Background Agents を3つ並列起動:

```
Background Agent 1: @security-review PR=<N>
Background Agent 2: モード切替「コードレビューモード」で diff レビュー
Background Agent 3: モード切替「QAエンジニアモード」で単体・E2E生成
```

3者の出力を docs/08-review-report.md に統合し、自動修正可能な指摘は適用、人判断が必要なものは残置。
