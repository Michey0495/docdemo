#!/usr/bin/env node
// lint-staged から呼ばれ、ステージ済みファイルに機密値が含まれないかチェック
import { execSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

const PATTERNS = [
  /AKIA[0-9A-Z]{16}/,                       // AWS Access Key
  /sk_live_[0-9a-zA-Z]{24}/,                // Stripe live key
  /-----BEGIN [A-Z ]+PRIVATE KEY-----/,     // PEM
]

const files = execSync('git diff --cached --name-only --diff-filter=ACMR')
  .toString().trim().split('\n').filter(Boolean)

for (const f of files) {
  const content = readFileSync(f, 'utf8')
  for (const re of PATTERNS) {
    if (re.test(content)) {
      console.error(`✗ Possible secret detected in ${f}`)
      process.exit(1)
    }
  }
}
