#!/usr/bin/env node
// Cursor の自動コマンド実行ポリシーに加え、独自にチェックする保険レイヤー
// .cursor/settings.json の "agent.beforeRunCommand" に紐づけて起動
import { argv, exit } from 'node:process'

const cmd = argv.slice(2).join(' ')
const danger = /git push.*--force|git reset --hard|^sudo |rm -rf //

if (danger.test(cmd)) {
  console.error(`✗ Blocked dangerous command: ${cmd}`)
  exit(1) // 非0で Agent が即座に停止
}
exit(0)
