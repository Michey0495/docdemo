---
id: US-XXX
related: FR-XXX, NFR-XXX
priority: Must|Should|Could
estimate: <1-13>pt
---
# US-XXX タイトル

As a <ロール>
I want <欲しい振る舞い>
So that <得られる価値>

## 受入基準
```gherkin
Feature: ...
  Scenario: 正常系
    Given ...
    When ...
    Then ...
```

## ワイヤーフレーム
```
（ASCII artで補強）
```
