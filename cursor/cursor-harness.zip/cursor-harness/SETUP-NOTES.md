# ファイルではなく設定画面・外部サービス側で行う項目

## 工程10 保守運用 — launchd / cron（外部スケジューラから cursor-agent 起動）

# crontab -e
# 毎朝9時 JST に Cursor CLI (cursor-agent) を非対話モードで起動
TZ=Asia/Tokyo
0 9 * * * /usr/local/bin/cursor-agent \
  --print \
  --mode prod-readonly \
  --workspace /opt/kakuu-stock \
  "@health-check 24h を実行し、エラー率/レスポンス分布/CSV連携成否を Datadog MCP 経由で取得し reports/daily/$(date +\%Y-\%m-\%d).md にまとめる。閾値超えがあれば Slack に通知。" \
  >> /var/log/cursor/daily-health.log 2>&1

# Cursor 単体には cron 機能が無いため、launchd / cron / systemd timer / GitHub Actions 等の
# 外部スケジューラから cursor-agent CLI を呼び出す運用が公式推奨パターン
# --mode で参照する Custom Mode は .cursor/modes/ または ~/.cursor/modes/ から読み込まれる
