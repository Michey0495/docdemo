# Claude Connectors / GitHub（任意）

Claude.ai の Connectors で GitHub をリモート接続すると、
設計決定を Issue として起票できる（MCP 経由）。

ChatGPT 側は GitHub コネクタ、
M365 Copilot 側は Azure DevOps エージェントが同等の役割。

接続しない場合は ADR を Markdown で出力し、人手で起票する。
