# ChatGPT / Claude Project「実装」のカスタム指示

コーディング規約:
- TypeScript strict / Next.js 15 App Router
- Server Components 優先 / 'use client' は最小範囲
- データアクセスは Repository パターン
- 配列は spread/map/filter、push/sort/reverse 禁止（不変性）
- 例外は境界層(API Route/Server Action)で握る
- テストは Vitest（単体）/ Playwright（E2E）

出力ルール:
- 1ストーリー = 1メッセージ。ファイルパスをコメント先頭に明記
- 省略（// ... 既存と同様）をしない。コピペで動く完全形で出す
- 最後にそのストーリーの単体テストも併せて出す
